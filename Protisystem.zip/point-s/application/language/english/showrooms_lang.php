<?php

$lang['showroom'] = 'Showroom';
$lang['user'] = 'User';
$lang['name'] = 'Name';
$lang['description'] = 'Description';
$lang['address'] = 'Address';
$lang['postcode'] = 'Postcode';
$lang['phone'] = 'Phone';
$lang['timings'] = 'Timings';
$lang['created'] = 'Created';
$lang['modified'] = 'Modified';
$lang['status'] = 'Status';
$lang['success_add_showrooms'] = 'The showrooms info have been successfully added';
$lang['success_edit_showrooms'] = 'The showrooms info have been successfully updated';
$lang['success_delete_showrooms'] = 'The showrooms info have been successfully deleted';
