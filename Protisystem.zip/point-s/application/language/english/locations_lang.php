<?php

$lang['heading'] = 'Heading';
$lang['meta_title'] = 'Meta Title';
$lang['meta_description'] = 'Meta Description';
$lang['meta_keywords'] = 'Meta Keywords';
$lang['content'] = 'Content';
$lang['created_at'] = 'Created At';
$lang['modified_at'] = 'Modified At';
$lang['status'] = 'Status';
$lang['success_add_locations'] = 'The locations info have been successfully added';
$lang['success_edit_locations'] = 'The locations info have been successfully updated';
$lang['success_delete_locations'] = 'The locations info have been successfully deleted';
