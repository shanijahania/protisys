<?php
/******************************************
US English
GoEdit Language
******************************************/

$lang['goedit_toggle_editor']	= 'Toggle Editor';
$lang['goedit_url']				= 'URL';
$lang['goedit_target']			= 'Target';
$lang['goedit_self']			= 'Self';
$lang['goedit_new_window']		= 'New Window';
$lang['goedit_class']			= 'Class';
$lang['goedit_insert_link']		= 'Insert Link';
$lang['goedit_root']			= 'Root';
$lang['goedit_upload']			= 'Upload';
$lang['goedit_loading']			= 'Loading';
$lang['goedit_rename']			= 'Rename';
$lang['goedit_warning']			= 'Warning!';
$lang['goedit_warning_text']	= 'Deleting a folder will result in the deletion of all it\'s contents. Are you sure you want to perform this action?';
$lang['goedit_delete_button']	= 'Yes, Delete it!';
$lang['goedit_image_details']	= 'Image Details';
$lang['goedit_alt']				= 'Alt';
$lang['goedit_width']			= 'Width';
$lang['goedit_height']			= 'Height';
$lang['goedit_title']			= 'Title';
$lang['goedit_insert_image']	= 'Insert Image';
$lang['goedit_update_image']	= 'Update Image';
$lang['goedit_folder_name']		= 'Folder Name';