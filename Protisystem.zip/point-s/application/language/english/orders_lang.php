<?php

$lang['first_name'] = 'First Name';
$lang['surname'] = 'Surname';
$lang['email'] = 'Email';
$lang['phone'] = 'Phone';
$lang['postcode'] = 'Postcode';
$lang['address'] = 'Address';
$lang['showroom'] = 'Showroom';
$lang['vehicle_registration'] = 'Vehicle Registration';
$lang['created_at'] = 'Created At';
$lang['modified_at'] = 'Modified At';
$lang['is_active'] = 'Is Active';
$lang['success_add_orders'] = 'The orders info have been successfully added';
$lang['success_edit_orders'] = 'The orders info have been successfully updated';
$lang['success_delete_orders'] = 'The orders info have been successfully deleted';
