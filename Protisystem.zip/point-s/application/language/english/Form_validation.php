<?php
$lang['is_unique'] = "The %s must contain a unique value."