<?php

$lang['name'] = 'Name';
$lang['link'] = 'Link';
$lang['description'] = 'Description';
$lang['age_group'] = 'Age Group';
$lang['target_locations'] = 'Target Locations';
$lang['started_at'] = 'Started At';
$lang['expired_at'] = 'Expired At';
$lang['displayed'] = 'Displayed';
$lang['clicks'] = 'Clicks';
$lang['users'] = 'Users';
$lang['image'] = 'Image';
$lang['thumb'] = 'Thumb';
$lang['created_at'] = 'Created At';
$lang['modified_at'] = 'Modified At';
$lang['is_active'] = 'Is Active';
$lang['success_add_ads'] = 'The ads info have been successfully added';
$lang['success_edit_ads'] = 'The ads info have been successfully updated';
$lang['success_delete_ads'] = 'The ads info have been successfully deleted';
