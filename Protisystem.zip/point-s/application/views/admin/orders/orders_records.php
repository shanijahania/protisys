<?php

$orders_records = array('first_name'=>'','surname'=>'','email'=>'','phone'=>'','postcode'=>'','address'=>'','showroom_id'=>'','vehicle_registration'=>'','created_at'=>'','modified_at'=>'','is_active'=>'');
$orders_records = (object)$orders_records;