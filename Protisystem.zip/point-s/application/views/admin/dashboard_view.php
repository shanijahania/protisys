<!-- <pre>
<?php //print_r(action_allowed('products', 'delete'));?>
</pre> -->
