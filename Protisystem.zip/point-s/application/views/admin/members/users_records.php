<?php

$users_records = array('name'=>'','surname'=>'','username'=>'','password'=>'','email'=>'','mobile'=>'','location'=>'','gender'=>'','avatar'=>'','access'=>'','is_active'=>'');
$users_records = (object)$users_records;